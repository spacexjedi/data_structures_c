Advanced C++ Programming Cookbook

All chapters have code files